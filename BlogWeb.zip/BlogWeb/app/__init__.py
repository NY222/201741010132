from flask import Flask
#导入配置文件
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
myApp = Flask(__name__)

myApp.config.from_object(Config)
myApp.config['SECRET_KEY']='123456'
#添加配置信息
db = SQLAlchemy(myApp)
#绑定app和数据库，以便进行操作
migrate = Migrate(myApp,db)
login = LoginManager(myApp)
login.login_view = 'login'

from app import routes,models
